﻿//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Cards
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string lines = string.Empty;
//            string path = @"D:\OLD\Ed\Projects\PC\PokerHands-input.txt";
//            StringBuilder sb = new StringBuilder(1000);
//            // string path = @"D:\OLD\Ed\Projects\PC\SmallSampleCards.txt";


//            using (StreamReader sr = new StreamReader(path))
//            {
//                lines = sr.ReadToEnd();
//            }

//            Stopwatch stopWatch = new Stopwatch();
//            stopWatch.Start();
//            string[] arrLines = lines.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
//            for (int i = 0; i < arrLines.Length; i++)
//            {
//                if (!string.IsNullOrEmpty(arrLines[i]))
//                {
//                    string[] allCards = arrLines[i].Split(' ');
//                    int blackTotal = ScoreCalculator.GetScore(new Hand(allCards.Take(5).ToArray()));
//                    int whiteTotal = ScoreCalculator.GetScore(new Hand(allCards.Skip(5).Take(5).ToArray()), blackTotal);
//                    if (blackTotal > whiteTotal)
//                        sb.AppendLine("Black Wins.");
//                    else if (whiteTotal > blackTotal)
//                        sb.AppendLine("White Wins.");
//                    else
//                        sb.AppendLine("Tie.");
//                }
//            }
          
//            stopWatch.Stop();
//            Console.WriteLine(sb.ToString());
//            Console.WriteLine(stopWatch.ElapsedMilliseconds);
//            Console.ReadLine();
//        }
//    }

//    class Hand
//    {
//        public Card Card1 { get; set; }
//        public Card Card2 { get; set; }
//        public Card Card3 { get; set; }
//        public Card Card4 { get; set; }
//        public Card Card5 { get; set; }
//        private bool sorted = false;
//        public bool SameSuit
//        {
//            get
//            {
//                return (Card1.Suit == Card2.Suit &&
//                    Card1.Suit == Card3.Suit &&
//                    Card1.Suit == Card4.Suit &&
//                    Card1.Suit == Card5.Suit);
//            }
//        }
//        public bool InOrder
//        {
//            get
//            {
//                Sort();
//                return (Card1.IntValue - 1 == Card2.IntValue &&
//                    Card2.IntValue - 1 == Card3.IntValue &&
//                    Card3.IntValue - 1 == Card4.IntValue &&
//                    Card4.IntValue - 1 == Card5.IntValue);
//            }
//        }

//        public bool IsFullHouse
//        {
//            get
//            {
//                Sort();
//                return (Card1.Value == Card3.Value && Card4.Value == Card5.Value) ||
//                    (Card1.Value == Card2.Value && Card3.Value == Card5.Value);
//            }
//        }

//        public bool IsFourOfAKind
//        {
//            get
//            {
//                Sort();
//                return (Card1.Value == Card4.Value || Card2.Value == Card5.Value);
//            }
//        }

//        public bool IsThreeOfAKind
//        {
//            get
//            {
//                Sort();
//                return (Card1.Value == Card3.Value || Card2.Value == Card4.Value || Card3.Value == Card5.Value);
//            }
//        }

//        public bool IsTwoPair
//        {
//            get
//            {
//                Sort();
//                return ((Card1.Value == Card2.Value && Card3.Value == Card4.Value) ||
//                    (Card2.Value == Card3.Value && Card4.Value == Card5.Value));
//            }
//        }

//        public bool IsPair
//        {
//            get
//            {
//                Sort();
//                return (Card1.Value == Card2.Value || Card2.Value == Card3.Value || Card3.Value == Card4.Value || Card4.Value == Card5.Value);
//            }
//        }

//        private void Sort()
//        {
//            if (!sorted)
//            {
//                List<Card> theList = new List<Card> { Card1, Card2, Card3, Card4, Card5 };
//                theList = theList.OrderBy(c => c.IntValue).ToList();
//                Card1 = theList[0];
//                Card2 = theList[1];
//                Card3 = theList[2];
//                Card4 = theList[3];
//                Card5 = theList[4];
//                sorted = true;
//            }
//        }


//        public Hand(string[] arrHand)
//        {
//            Array.Sort(arrHand);
//            Card1 = new Card(arrHand[0]);
//            Card2 = new Card(arrHand[1]);
//            Card3 = new Card(arrHand[2]);
//            Card4 = new Card(arrHand[3]);
//            Card5 = new Card(arrHand[4]);
//        }
//    }

//    class Card
//    {
//        private string _value = string.Empty;
//        private string _suit = string.Empty;

//        public string Value
//        {
//            get
//            {
//                return _value;
//            }
//        }
//        public string Suit
//        {
//            get
//            {
//                return _suit;
//            }
//        }

//        public int IntValue
//        {
//            get
//            {
//                switch (_value)
//                {
//                    case "A":
//                        return 13;
//                    case "K":
//                        return 12;
//                    case "Q":
//                        return 11;
//                    case "J":
//                        return 10;
//                    case "T":
//                        return 9;
//                    case "9":
//                        return 8;
//                    case "8":
//                        return 7;
//                    case "7":
//                        return 6;
//                    case "6":
//                        return 5;
//                    case "5":
//                        return 4;
//                    case "4":
//                        return 3;
//                    case "3":
//                        return 2;
//                    case "2":
//                        return 1;
//                }
//                return 0;
//            }
//        }

//        public Card(string aCard)
//        {
//            _value = aCard.Substring(0, 1);
//            _suit = aCard.Substring(1, 1);
//        }
//    }

//    static class ScoreCalculator
//    {
//        public static int GetScore(Hand theHand, int firstScore)
//        {
//            const int scoreMultiplier = 100000000;
//            bool sameSuit = theHand.SameSuit;
//            bool flush = theHand.InOrder;

//            if (sameSuit & flush)
//                return (9 * scoreMultiplier) + HighCardTotal(theHand); // Straight Flush
//            else if (firstScore > (9 * scoreMultiplier))
//                return 0;
//            else if (theHand.IsFourOfAKind)
//                return (8 * scoreMultiplier) + HighCardTotal(theHand);
//            else if (firstScore > (8 * scoreMultiplier))
//                return 0;
//            else if (theHand.IsFullHouse)
//                return (7 * scoreMultiplier) + HighCardTotal(theHand);
//            else if (firstScore > (7 * scoreMultiplier))
//                return 0;
//            else if (sameSuit)
//                return (6 * scoreMultiplier) + HighCardTotal(theHand); // Flush
//            else if (firstScore > (6 * scoreMultiplier))
//                return 0;
//            else if (theHand.InOrder)
//                return (5 * scoreMultiplier) + HighCardTotal(theHand);
//            else if (firstScore > (5 * scoreMultiplier))
//                return 0;
//            else if (theHand.IsThreeOfAKind)
//                return (4 * scoreMultiplier) + HighCardTotal(theHand);
//            else if (firstScore > (4 * scoreMultiplier))
//                return 0;
//            else if (theHand.IsTwoPair)
//                return (3 * scoreMultiplier) + HighCardTotal(theHand);
//            else if (firstScore > (3 * scoreMultiplier))
//                return 0;
//            else if (theHand.IsPair)
//                return (2 * scoreMultiplier) + HighCardTotal(theHand);

//            return HighCardTotal(theHand);
//        }

//        public static int GetScore(Hand theHand)
//        {
//            const int scoreMultiplier = 100000000;
//            bool sameSuit = theHand.SameSuit;
//            bool flush = theHand.InOrder;

//            if (sameSuit & flush)
//                return (9 * scoreMultiplier) + HighCardTotal(theHand); // Straight Flush

//            else if (theHand.IsFourOfAKind)
//                return (8 * scoreMultiplier) + HighCardTotal(theHand);

//            else if (theHand.IsFullHouse)
//                return (7 * scoreMultiplier) + HighCardTotal(theHand);

//            else if (sameSuit)
//                return (6 * scoreMultiplier) + HighCardTotal(theHand); // Flush

//            else if (theHand.InOrder)
//                return (5 * scoreMultiplier) + HighCardTotal(theHand);

//            else if (theHand.IsThreeOfAKind)
//                return (4 * scoreMultiplier) + HighCardTotal(theHand);

//            else if (theHand.IsTwoPair)
//                return (3 * scoreMultiplier) + HighCardTotal(theHand);

//            else if (theHand.IsPair)
//                return (2 * scoreMultiplier) + HighCardTotal(theHand);

//            return HighCardTotal(theHand);
//        }

//        private static int HighCardTotal(Hand theHand)
//        {
//            return HighCard(theHand.Card1.Value) +
//                HighCard(theHand.Card2.Value) +
//               HighCard(theHand.Card3.Value) +
//               HighCard(theHand.Card4.Value) +
//               HighCard(theHand.Card5.Value);
//        }


//        private static int HighCard(string value)
//        {
//            switch (value)
//            {
//                case "A":
//                    return 22369621;
//                case "K":
//                    return 5592405;
//                case "Q":
//                    return 1398101;
//                case "J":
//                    return 349525;
//                case "T":
//                    return 87381;
//                case "9":
//                    return 21845;
//                case "8":
//                    return 5461;
//                case "7":
//                    return 1365;
//                case "6":
//                    return 341;
//                case "5":
//                    return 85;
//                case "4":
//                    return 21;
//                case "3":
//                    return 5;
//                case "2":
//                    return 1;
//            }
//            return 0;
//        }
//    }
//}
