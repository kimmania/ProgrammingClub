﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cards
{
    public class Hand
    {
        public Card Card1 { get; set; }
        public Card Card2 { get; set; }
        public Card Card3 { get; set; }
        public Card Card4 { get; set; }
        public Card Card5 { get; set; }

        public bool SameSuit
        {
            get
            {
                return (Card1.Suit == Card2.Suit &&
                    Card1.Suit == Card3.Suit &&
                    Card1.Suit == Card4.Suit &&
                    Card1.Suit == Card5.Suit);
            }
        }
        public bool InOrder
        {
            get
            {
                return (Card1.Value + 1 == Card2.Value &&
                    Card2.Value + 1 == Card3.Value &&
                    Card3.Value + 1 == Card4.Value &&
                    Card4.Value + 1 == Card5.Value);
            }
        }

        public bool IsFullHouse
        {
            get
            {
                
                return  (Card1.Value == Card3.Value && Card4.Value == Card5.Value) ||
                    (Card1.Value == Card2.Value && Card3.Value == Card5.Value);
            }
        }

        public Tuple<int, int> FullHouseCards
        {
            get
            {
                if (Card1.Value == Card3.Value)
                    return new Tuple<int, int>(Card1.Value, Card4.Value);
                else
                    return new Tuple<int, int>(Card3.Value, Card1.Value);
            }
             
            
        }

        public bool IsFourOfAKind
        {
            get
            {
               return (Card1.Value == Card4.Value || Card2.Value == Card5.Value);
            }
        }

        public bool IsThreeOfAKind
        {
            get
            {
                return (Card1.Value == Card3.Value || Card2.Value == Card4.Value || Card3.Value == Card5.Value);
            }
        }

        public bool IsTwoPair
        {
            get
            {
                return (((Card1.Value == Card2.Value) && (Card3.Value == Card4.Value)) || ((Card1.Value == Card2.Value) && (Card4.Value == Card5.Value)) || ((Card2.Value == Card3.Value) && (Card4.Value == Card5.Value)));
            }
        }

        public Tuple<int, int, int> TwoPairCards
        {
            get
            {
                if (Card1.Value == Card2.Value && Card3.Value == Card4.Value)
                    return new Tuple<int, int, int>(Card3.Value, Card1.Value, Card5.Value);
                else if ((Card1.Value == Card2.Value) && (Card4.Value == Card5.Value))
                    return new Tuple<int, int, int>(Card5.Value, Card2.Value, Card3.Value);
                else
                    return new Tuple<int, int, int>(Card5.Value, Card3.Value, Card1.Value);
            }
        }

        public bool IsPair
        {
            get
            {
                return (Card1.Value == Card2.Value || Card2.Value == Card3.Value || Card3.Value == Card4.Value || Card4.Value == Card5.Value);
            }
        }


        public Tuple<int, int, int, int> PairCards
        {
            get
            {
                if (Card1.Value == Card2.Value)
                    return new Tuple<int, int, int, int>(Card1.Value, Card5.Value, Card4.Value, Card3.Value);
                else if (Card2.Value == Card3.Value)
                    return new Tuple<int, int, int, int>(Card2.Value, Card5.Value, Card4.Value, Card1.Value);
                else if (Card3.Value == Card4.Value)
                    return new Tuple<int, int, int, int>(Card3.Value, Card5.Value, Card2.Value, Card1.Value);
                else
                    return new Tuple<int, int, int, int>(Card5.Value, Card3.Value, Card2.Value, Card1.Value);
            }
        }


        public Hand(string[] arrHand)
        {
            List<Card> theList = new List<Card> { new Card(arrHand[0]), new Card(arrHand[1]), new Card(arrHand[2]), new Card(arrHand[3]), new Card(arrHand[4]) };
            theList = theList.OrderBy(c => c.Value).ToList();
            Card1 = theList[0];
            Card2 = theList[1];
            Card3 = theList[2];
            Card4 = theList[3];
            Card5 = theList[4];
        }
    }
}
