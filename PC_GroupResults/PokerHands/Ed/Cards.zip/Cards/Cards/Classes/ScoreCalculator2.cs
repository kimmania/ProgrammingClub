﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cards
{
   public static class ScoreCalculator2
    {
        public static int FindWinner(Hand hand1, Hand hand2)
        {
            bool hand1SameSuit = hand1.SameSuit;
            bool hand1Flush = hand1.InOrder;
            bool hand2SameSuit = hand2.SameSuit;
            bool hand2Flush = hand2.InOrder;

            bool hand1Pair = hand1.IsPair;
            bool hand2Pair = hand2.IsPair;

            //Straight Flush?
            bool hand1StraightFlush = hand1.SameSuit && hand1Flush;
            bool hand2StraightFlush = hand2SameSuit && hand2Flush;
            if (hand1StraightFlush && hand2StraightFlush)
                return TieBreaker.BreakTieOnlyNeedToConsiderOneCard(hand1.Card5.Value, hand2.Card5.Value);
            else if (hand1StraightFlush && !hand2StraightFlush)
                return 1;
            else if (hand2StraightFlush && !hand1StraightFlush)
                return 2;



            //Four of a kind?
            bool hand1FourOfAKind;
            if (!hand1Pair)
                hand1FourOfAKind = false;
            else
                hand1FourOfAKind = hand1.IsFourOfAKind;

            bool hand2FourOfAKind;
            if (!hand2Pair)
                hand2FourOfAKind = false;
            else
                hand2FourOfAKind = hand2.IsFourOfAKind;

            if (hand1FourOfAKind && hand2FourOfAKind)
                return TieBreaker.BreakTieOnlyNeedToConsiderOneCard(hand1.Card3.Value, hand2.Card3.Value); //3rd card will always be part of the four of a kind.
            else if (hand1FourOfAKind && !hand2FourOfAKind)
                return 1;
            else if (hand2FourOfAKind && !hand1FourOfAKind)
                return 2;



            //Full House?
            bool hand1FullHouse;
            if (!hand1Pair)
                hand1FullHouse = false;
            else
                hand1FullHouse = hand1.IsFullHouse;

            bool hand2FullHouse;
            if (!hand2Pair)
                hand2FullHouse = false;
            else
                hand2FullHouse = hand2.IsFullHouse;

            if (hand1FullHouse && hand2FullHouse)
                return TieBreaker.BreakTieConsiderTwoCards(hand1.FullHouseCards.Item1, hand1.FullHouseCards.Item2, hand2.FullHouseCards.Item1, hand2.FullHouseCards.Item2);
            else if (hand1FullHouse && !hand2FullHouse)
                return 1;
            else if (hand2FullHouse && !hand1FullHouse)
                return 2;

            //Straight?
            if (hand1SameSuit && hand2SameSuit)
                return TieBreaker.BreakTieCondsiderAll(hand1, hand2);
            else if (hand1SameSuit && !hand2SameSuit)
                return 1;
            else if (hand2SameSuit && !hand1SameSuit)
                return 2;

            //Flush
            if (hand1Flush && hand2Flush)
                return TieBreaker.BreakTieOnlyNeedToConsiderOneCard(hand1.Card5.Value, hand2.Card5.Value); 
            else if (hand1Flush && !hand2Flush)
                return 1;
            else if (hand2Flush && !hand1Flush)
                return 2;

            //3 of a kind
            bool hand13OfAKind;
            if (!hand1Pair)
                hand13OfAKind = false;
            else
                hand13OfAKind = hand1.IsThreeOfAKind;

            bool hand23OfAKind;
            if (!hand2Pair)
                hand23OfAKind = false;
            else
                hand23OfAKind = hand2.IsThreeOfAKind;

            if (hand13OfAKind && hand23OfAKind)
                return TieBreaker.BreakTieOnlyNeedToConsiderOneCard(hand1.Card3.Value, hand2.Card3.Value); //3rd card will always be part of the three of a kind.
            else if (hand13OfAKind && !hand23OfAKind)
                return 1;
            else if (hand23OfAKind && !hand13OfAKind)
                return 2;

            //2 Pair
            bool hand12Pair;
            if (!hand1Pair)
                hand12Pair = false;
            else
                hand12Pair = hand1.IsTwoPair;

            bool hand22Pair;
            if (!hand2Pair)
                hand22Pair = false;
            else
                hand22Pair = hand2.IsTwoPair;

            if (hand12Pair && hand22Pair)
                return TieBreaker.BreakTieConsiderThreeCards(hand1.TwoPairCards.Item1, hand1.TwoPairCards.Item2, hand1.TwoPairCards.Item3, hand2.TwoPairCards.Item1, hand2.TwoPairCards.Item2, hand2.TwoPairCards.Item3);
            else if (hand12Pair && !hand22Pair)
                return 1;
            else if (hand22Pair && !hand12Pair)
                return 2;

            //Pair

            if (hand1Pair && hand2Pair)
                return TieBreaker.BreakTieConsiderFourCards(hand1.PairCards, hand2.PairCards);
            else if (hand1Pair && !hand2Pair)
                return 1;
            else if (hand2Pair && !hand1Pair)
                return 2;

            //High Card
            return TieBreaker.BreakTieCondsiderAll(hand1, hand2);
        }
    }
}
