﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cards
{
  public  class Card
    {
        private int _value = 0;
        private string _suit = string.Empty;

        public int Value
        {
            get
            {
                return _value;
            }
        }
        public string Suit
        {
            get
            {
                return _suit;
            }
        }

        private int IntValue(string value)
        {

            switch (value)
            {
                case "A":
                    return 13;
                case "K":
                    return 12;
                case "Q":
                    return 11;
                case "J":
                    return 10;
                case "T":
                    return 9;
                case "9":
                    return 8;
                case "8":
                    return 7;
                case "7":
                    return 6;
                case "6":
                    return 5;
                case "5":
                    return 4;
                case "4":
                    return 3;
                case "3":
                    return 2;
                case "2":
                    return 1;
            }
            return 0;
        }

        public Card(string aCard)
        {
            _value = IntValue(aCard.Substring(0, 1));
            _suit = aCard.Substring(1, 1);
        }
    }
}
