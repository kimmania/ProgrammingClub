﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cards
{
    static class ScoreCalculator
    {
        public static int GetScore(Hand theHand, int firstScore)
        {
            const int scoreMultiplier = 100000000;
            bool sameSuit = theHand.SameSuit;
            bool flush = theHand.InOrder;

            if (sameSuit & flush)
                return (9 * scoreMultiplier) + HighCardTotal(theHand); // Straight Flush
            else if (firstScore > (9 * scoreMultiplier))
                return 0;
            else if (theHand.IsFourOfAKind)
                return (8 * scoreMultiplier) + HighCardTotal(theHand);
            else if (firstScore > (8 * scoreMultiplier))
                return 0;
            else if (theHand.IsFullHouse)
                return (7 * scoreMultiplier) + HighCardTotal(theHand);
            else if (firstScore > (7 * scoreMultiplier))
                return 0;
            else if (sameSuit)
                return (6 * scoreMultiplier) + HighCardTotal(theHand); // Flush
            else if (firstScore > (6 * scoreMultiplier))
                return 0;
            else if (theHand.InOrder)
                return (5 * scoreMultiplier) + HighCardTotal(theHand);
            else if (firstScore > (5 * scoreMultiplier))
                return 0;
            else if (theHand.IsThreeOfAKind)
                return (4 * scoreMultiplier) + HighCardTotal(theHand);
            else if (firstScore > (4 * scoreMultiplier))
                return 0;
            else if (theHand.IsTwoPair)
                return (3 * scoreMultiplier) + HighCardTotal(theHand);
            else if (firstScore > (3 * scoreMultiplier))
                return 0;
            else if (theHand.IsPair)
                return (2 * scoreMultiplier) + HighCardTotal(theHand);

            return HighCardTotal(theHand);
        }

        public static int GetScore(Hand theHand)
        {
            const int scoreMultiplier = 100000000;
            bool sameSuit = theHand.SameSuit;
            bool flush = theHand.InOrder;

            if (sameSuit & flush)
                return (9 * scoreMultiplier) + HighCardTotal(theHand); // Straight Flush

            else if (theHand.IsFourOfAKind)
                return (8 * scoreMultiplier) + HighCardTotal(theHand);

            else if (theHand.IsFullHouse)
                return (7 * scoreMultiplier) + HighCardTotal(theHand);

            else if (sameSuit)
                return (6 * scoreMultiplier) + HighCardTotal(theHand); // Flush

            else if (theHand.InOrder)
                return (5 * scoreMultiplier) + HighCardTotal(theHand);

            else if (theHand.IsThreeOfAKind)
                return (4 * scoreMultiplier) + HighCardTotal(theHand);

            else if (theHand.IsTwoPair)
                return (3 * scoreMultiplier) + HighCardTotal(theHand);

            else if (theHand.IsPair)
                return (2 * scoreMultiplier) + HighCardTotal(theHand);

            return HighCardTotal(theHand);
        }

        private static int HighCardTotal(Hand theHand)
        {
            return HighCard(theHand.Card1.Value) +
                HighCard(theHand.Card2.Value) +
               HighCard(theHand.Card3.Value) +
               HighCard(theHand.Card4.Value) +
               HighCard(theHand.Card5.Value);
        }


        private static int HighCard(int value)
        {
            switch (value)
            {
                case 13:
                    return 22369621;
                case 12:
                    return 5592405;
                case 11:
                    return 1398101;
                case 10:
                    return 349525;
                case 9:
                    return 87381;
                case 8:
                    return 21845;
                case 7:
                    return 5461;
                case 6:
                    return 1365;
                case 5:
                    return 341;
                case 4:
                    return 85;
                case 3:
                    return 21;
                case 2:
                    return 5;
                case 1:
                    return 1;
            }
            return 0;
        }
    }
}
