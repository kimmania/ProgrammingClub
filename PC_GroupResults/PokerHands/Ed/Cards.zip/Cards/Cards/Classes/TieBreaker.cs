﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cards
{
    public static class TieBreaker
    {
        public static int BreakTieOnlyNeedToConsiderOneCard(int firstGuysCard, int secondGuysCard)
        {
            if (firstGuysCard > secondGuysCard)
                return 1;
            else if (secondGuysCard > firstGuysCard)
                return 2;
            else
                return 0;
        }

        public static int BreakTieConsiderTwoCards(int firstGuysPriority1, int firstGuysPriority2, int secondGuysPriority1, int secondGuysPriority2)
        {
            if (firstGuysPriority1 > secondGuysPriority1)
                return 1;
            else if(secondGuysPriority1 > firstGuysPriority1)
                return 2;
            else
                return BreakTieOnlyNeedToConsiderOneCard(firstGuysPriority2, secondGuysPriority2);
        }

        public static int BreakTieConsiderThreeCards(int firstGuysPriority1, int firstGuysPriority2, int firstGuysPriority3, int secondGuysPriority1, int secondGuysPriority2, int secondGuysPriority3)
        {
            if (firstGuysPriority1 > secondGuysPriority1)
                return 1;
            else if (secondGuysPriority1 > firstGuysPriority1)
                return 2;
            else
                return BreakTieConsiderTwoCards(firstGuysPriority2, firstGuysPriority3, secondGuysPriority2, secondGuysPriority3);
        }

        public static int BreakTieConsiderFourCards(Tuple <int, int, int, int> firstGuy, Tuple <int, int, int, int> secondGuy)
        {
            if (firstGuy.Item1 > secondGuy.Item1)
                return 1;
            else if (secondGuy.Item1 > firstGuy.Item1)
                return 2;
            else
                return BreakTieConsiderThreeCards(firstGuy.Item2, firstGuy.Item3, firstGuy.Item4, secondGuy.Item2, secondGuy.Item3, secondGuy.Item4);
        }

        //Ordered lowest to highest
        public static int BreakTieCondsiderAll(Hand hand1, Hand hand2)
        {
            // Compare first cards
            int compare = BreakTieOnlyNeedToConsiderOneCard(hand1.Card5.Value, hand2.Card5.Value);
            if (compare > 0)
                return compare;

            //Second
            compare = BreakTieOnlyNeedToConsiderOneCard(hand1.Card4.Value, hand2.Card4.Value);
            if (compare > 0)
                return compare;

            //Third
            compare = BreakTieOnlyNeedToConsiderOneCard(hand1.Card3.Value, hand2.Card3.Value);
            if (compare > 0)
                return compare;

            //Fourth
            compare = BreakTieOnlyNeedToConsiderOneCard(hand1.Card2.Value, hand2.Card2.Value);
            if (compare > 0)
                return compare;

            return BreakTieOnlyNeedToConsiderOneCard(hand1.Card1.Value, hand2.Card1.Value);
        }
    }
}
