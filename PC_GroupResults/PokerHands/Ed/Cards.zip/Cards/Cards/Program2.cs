﻿//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Cards
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string lines = string.Empty;
//            string path = @"D:\OLD\Ed\Projects\PC\PokerHands-input.txt";
//            StringBuilder sb = new StringBuilder(1000);
//            // string path = @"D:\OLD\Ed\Projects\PC\SmallSampleCards.txt";


//            using (StreamReader sr = new StreamReader(path))
//            {
//                lines = sr.ReadToEnd();
//            }

//            Stopwatch stopWatch = new Stopwatch();
//            stopWatch.Start();
//            string[] arrLines = lines.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

//            for (int i = 0; i < arrLines.Length; i++)
//            {
//                if (!string.IsNullOrEmpty(arrLines[i]))
//                {
//                    string[] allCards = arrLines[i].Split(' ');
//                    int julesTotal = ScoreCalculator.GetScore(new Hand(allCards.Take(5).ToArray()));
//                    int vincentTotal = ScoreCalculator.GetScore(new Hand(allCards.Skip(5).Take(5).ToArray()), julesTotal);
//                    if (julesTotal > vincentTotal)
//                        sb.AppendLine("Black Wins.");
//                    else if (vincentTotal > julesTotal)
//                        sb.AppendLine("White Wins.");
//                    else
//                        sb.AppendLine("Tie.");
//                }
//            }

//            stopWatch.Stop();
//            Console.WriteLine(sb.ToString());
//            Console.WriteLine(stopWatch.ElapsedMilliseconds);
//            Console.ReadLine();
//        }
//    }
//}
