﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Cards
{
    class Program3
    {
        static void Main(string[] args)
        {
            string lines = string.Empty;
      //   string path = @"D:\OLD\Ed\Projects\PC\PokerHands-input.txt";
         //  string path = @"D:\OLD\Ed\Projects\PC\PokerHands-inputscenarios.txt";
       //     string path = @"D:\OLD\Ed\Projects\PC\PokerHands-input-sorted.txt";
            Console.Write("Enter path:");
            string path = Console.ReadLine();
            

            List<long> times = new List<long>(100);
            //  StringBuilder sb = new StringBuilder(1000);
           //  string path = @"D:\OLD\Ed\Projects\PC\SmallSampleCards.txt";


            using (StreamReader sr = new StreamReader(path))
            {
                lines = sr.ReadToEnd();
            }

            for (int j = 0; j < 101; j++)
            {
                int blackWins = 0;
                int whiteWins = 0;
                int ties = 0;
                StringBuilder sb = new StringBuilder(10);
                Stopwatch stopWatch = new Stopwatch();
                stopWatch.Start();
                string[] arrLines = lines.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

                Parallel.ForEach(arrLines, new ParallelOptions { MaxDegreeOfParallelism = 4 }, theLine =>
                {
                    if (!string.IsNullOrEmpty(theLine))
                    {
                        string[] allCards = theLine.Split(' ');
                        Hand julesHand = new Hand(allCards.Take(5).ToArray());
                        Hand vincentHand = new Hand(allCards.Skip(5).Take(5).ToArray());
                        int winner = ScoreCalculator2.FindWinner(julesHand, vincentHand);
                        if (winner == 1)
                            Interlocked.Increment(ref blackWins);
                        else if (winner == 2)
                            Interlocked.Increment(ref whiteWins);
                        else
                            Interlocked.Increment(ref ties);
                    }
                });

               // Tuple<int, int, int> results =  EvaluateParallel(lines);

                //////for (int i=0; i < arrLines.Length; i++)
                ////// {
                //////     if (!string.IsNullOrEmpty(arrLines[i]))
                //////     {
                //////         string[] allCards = arrLines[i].Split(' ');
                //////         Hand julesHand = new Hand(allCards.Take(5).ToArray());
                //////         Hand vincentHand = new Hand(allCards.Skip(5).Take(5).ToArray());
                //////         int winner = ScoreCalculator2.FindWinner(julesHand, vincentHand);
                //////         if (winner == 1)
                //////             blackWins++;
                //////         else if (winner == 2)
                //////             whiteWins++;
                //////         else
                //////             ties++; ;
                //////     }
                ////// };

                if (j == 0)
                {
                    sb.Append("Black Wins: ");
                    sb.AppendLine(blackWins.ToString());
                    sb.Append("White Wins: ");
                    sb.AppendLine(whiteWins.ToString());
                    sb.Append("Ties: ");
                    sb.AppendLine(ties.ToString());

                    Console.WriteLine(sb.ToString());
                }
               


                stopWatch.Stop();
                if (j > 0)
                    times.Add(stopWatch.ElapsedMilliseconds);
            }

            Console.WriteLine("Max: " + times.Max());
            Console.WriteLine("Min: " + times.Min());
            Console.WriteLine("Average: " + times.Average());
          //  Console.WriteLine("Median: " + GetMedian(times));
            Console.ReadLine();
        }

        //private static Tuple <int, int, int> EvaluateParallel(string lines)
        //{
        //    int _blackWins = 0;
        //    int _whiteWins = 0;
        //    int _ties = 0;
        //    string[] arrLines = lines.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
        //    //using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\Public\TestFolder\WriteLines2.txt"))
        //    //{
        //       Parallel.ForEach(arrLines, new ParallelOptions { MaxDegreeOfParallelism = 4 }, theLine =>
        //        {
        //            if (!string.IsNullOrEmpty(theLine))
        //            {
        //                string[] allCards = theLine.Split(' ');
        //                Hand julesHand = new Hand(allCards.Take(5).ToArray());
        //                Hand vincentHand = new Hand(allCards.Skip(5).Take(5).ToArray());
        //                int winner = ScoreCalculator2.FindWinner(julesHand, vincentHand);
        //                if (winner == 1)
        //                {
        //                 //   file.WriteLine(theLine + "-BLACK");
        //                    Interlocked.Increment(ref _blackWins);
        //                }

        //                else if (winner == 2)
        //                {
        //               //     file.WriteLine(theLine + "-WHITE");
        //                    Interlocked.Increment(ref _whiteWins);
        //                }

        //                else
        //                {
        //                    // Console.WriteLine("TIE");
        //                    Interlocked.Increment(ref _ties);
        //                }

        //            }

        //        });
        //    //}
        //    return new Tuple<int, int, int>(_blackWins, _whiteWins, _ties);
        //}

        private static long GetMedian(List<long> numbers)
        {
            int numberCount = numbers.Count();
            int halfIndex = numbers.Count() / 2;
            var sortedNumbers = numbers.OrderBy(n => n);
            long median;
            if ((numberCount % 2) == 0)
            {
                median = ((sortedNumbers.ElementAt(halfIndex) + sortedNumbers.ElementAt((halfIndex - 1) / 2)));
            }
            else
            {
                median = sortedNumbers.ElementAt(halfIndex);
            }
            return median;
        }
    }
}
