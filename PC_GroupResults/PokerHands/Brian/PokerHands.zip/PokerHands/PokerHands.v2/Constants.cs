﻿using System;

namespace PokerHands.v2
{
    public static class Constants
    {

        public enum HandResult
        {
            HighCard = '0',
            Pair = '1',
            TwoPairs = '2',
            ThreeOfKind = '3',
            Straight = '4',
            Flush = '5',
            FullHouse = '6',
            FourOfKind = '7',
            StraightFlush = '8'
        }

    }  // end class
}  // end namespace
