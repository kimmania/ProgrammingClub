﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System.Collections.Concurrent;
using System.IO;

using PokerHands.Globals;

namespace PokerHands.v2
{
    public class Executor : IExecute
    {
        public string ResultsFileName { get; set; }
        //
        // do not initialize any fields here. that must be done after starting the timer
        //
        string[] inputFileContents;

        private char[] cardSeparator;
        private StringBuilder cardParser;

        private object lockerHandsWonByBlack = new object();
        private int handsWonByBlack;

        private object lockerHandsWonByWhite = new object();
        private int handsWonByWhite;

        private object lockerHandsTied = new object();
        private int handsTied;

        public ExecuteResults Execute(string inputFileName)
        {
            //
            // initialize stuff that's allowed before starting timer
            //
            inputFileContents = File.ReadAllLines(inputFileName);
            //
            // start timer
            //
            Stopwatch sw = new Stopwatch();
            sw.Start();
            //
            // initialize other stuff now that the timer is ticking
            //
            handsWonByBlack = 0;
            handsWonByWhite = 0;
            handsTied = 0;
            ExecuteResults results = new ExecuteResults();

            cardSeparator = new char[] { ' ' };
            cardParser = BuildCardParser();

            using (var wtr = OpenOutputFile())
            {
                ProcessFile(wtr);
                sw.Stop();
                wtr.WriteLine(String.Format(
                    "Elapsed: ms: {0}, ticks: {1}",
                    sw.ElapsedMilliseconds,
                    sw.ElapsedTicks));
                results.ExecutionTimeMilliseconds = sw.ElapsedMilliseconds;
                results.ExecutionTimeTicks = sw.ElapsedTicks;
            }  // end using wtr

            return results;
        }

        private TextWriter OpenOutputFile()
        {
            string outputDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            ResultsFileName = Path.Combine(outputDirectory, "results-Brian.txt");
            return File.CreateText(ResultsFileName);
        }

        private void ProcessFile(TextWriter wtr)
        {
            try
            {
                Parallel.ForEach(inputFileContents, record => ProcessHand(wtr, record));

                wtr.WriteLine(String.Format(
                    "Black: {0}, white: {1}, ties: {2}",
                    handsWonByBlack,
                    handsWonByWhite,
                    handsTied));
            }
            catch(Exception ex)
            {
                wtr.WriteLine("Exception");
                wtr.WriteLine(ex.ToString());
            }
        }

        private StringBuilder BuildCardParser()
        {
            // StringBuilder uses mutable character array for building the string. use
            // it to map a card rank to a score

            char[] map = (char[])Array.CreateInstance(typeof(char), 256);

            StringBuilder sb = new StringBuilder(new string(map));

            sb[(int)'2'] = 'a';
            sb[(int)'3'] = 'b';
            sb[(int)'4'] = 'c';
            sb[(int)'5'] = 'd';
            sb[(int)'6'] = 'e';
            sb[(int)'7'] = 'f';
            sb[(int)'8'] = 'g';
            sb[(int)'9'] = 'h';
            sb[(int)'T'] = 'i';
            sb[(int)'J'] = 'j';
            sb[(int)'Q'] = 'k';
            sb[(int)'K'] = 'l';
            sb[(int)'A'] = 'm';

            return sb;
        }

        private void ProcessHand(TextWriter wtr, string record)
        {
#if DETAILED_OUTPUT
            wtr.WriteLine("------------------------------------");
            wtr.WriteLine(record.Insert(14, " |"));
#endif

            string[] cardsForBothPlayers = record.Split(cardSeparator);

            string blackScore = CalculateHandScore(cardsForBothPlayers, 0);
            string whiteScore = CalculateHandScore(cardsForBothPlayers, 5);

#if DETAILED_OUTPUT
            wtr.WriteLine(String.Format("Black score: {0}", blackScore).Replace('\0', '+'));
            wtr.WriteLine(String.Format("White score: {0}", whiteScore).Replace('\0', '+'));
#endif

            int scoreComparer = blackScore.CompareTo(whiteScore);
            if (scoreComparer > 0)
            {
                lock (lockerHandsWonByBlack)
                {
                    handsWonByBlack++;
                }  // end lock
                
#if DETAILED_OUTPUT
                wtr.WriteLine("Black wins.");
#endif
            }
            else if (scoreComparer < 0)
            {
                lock (lockerHandsWonByWhite)
                {
                    handsWonByWhite++;
                }  // end lock
                
#if DETAILED_OUTPUT
                wtr.WriteLine("White wins.");
#endif
            }
            else
            {
                lock (lockerHandsTied)
                {
                    handsTied++;
                }  // end lock
#if DETAILED_OUTPUT
                wtr.WriteLine("Tie.");
#endif
            }
        }

        private string CalculateHandScore(string[] cards, int indexFirstCard)
        {
            // calculate a string representing the player's score for this hand.

            StringBuilder rankedHand = new StringBuilder("\0",6);

            // used for tracking pairs
            Dictionary<char, int> pairs = null;

            // used for finding flush
            int[] suitCounts = new int[256];

            // current card info
            string card;
            char cardRank;
            char cardValue;
            char suit;

            for (int c = 0; c < 5; c++ )
            {
                card = cards[c + indexFirstCard];
                cardRank = card[0];
                suit = card[1];
                cardValue = cardParser[cardRank];

                // add card to array for ordering cards by value
                for (int r = 0; r <= c; r++)
                {
                    if (cardValue >= rankedHand[r])
                    {
                        rankedHand.Insert(r, cardValue);
                        break;
                    }
                }

                // bump count for suit
                suitCounts[(int)suit]++;

                UpdatePairs(ref pairs, cardValue);
            }

            // order pairs to detect 4 of a kind, full house, 3 of a kind, two pairs, pair
            var orderedPairs = pairs
                .OrderByDescending(p => p.Value)
                .ThenBy(s => s.Key)
                .ToArray();

            // four of a kind (3333K), score as 7b0.l0000
            if (orderedPairs[0].Value == 4)
            {
                return new string(new char[] 
                { 
                    (char) Constants.HandResult.FourOfKind,
                    orderedPairs[0].Key,
                    orderedPairs[1].Key
                });
            }

            if (orderedPairs[0].Value == 3)
            {
                if (orderedPairs[1].Value == 2)
                {
                    // full house (33322), score as 6ba.00000
                    return new string(new char[] 
                    {
                        (char) Constants.HandResult.FullHouse,
                        orderedPairs[0].Key,
                        orderedPairs[1].Key
                    });
                }
                else
                {
                    // three of a kind (555KA), score as 3d0.lm000
                    return new string(new char[] 
                    {
                        (char) Constants.HandResult.ThreeOfKind,
                        orderedPairs[0].Key,
                        orderedPairs[1].Key,
                        orderedPairs[2].Key
                    });
                }
            }

            // two pairs (9955Q), score as 3hd.k0000
            if ((orderedPairs[0].Value == 2) && (orderedPairs[1].Value == 2))
            {
                return new string(new char[] 
                {
                    (char) Constants.HandResult.TwoPairs,
                    orderedPairs[0].Key,
                    orderedPairs[1].Key,
                    orderedPairs[2].Key
                });
            }

            // one pair (AA584), score as 1m0.dgc00
            if (orderedPairs[0].Value == 2)
            {
                return new string(new char[] 
                {
                    (char) Constants.HandResult.Pair,
                    orderedPairs[0].Key,
                    orderedPairs[1].Key,
                    orderedPairs[2].Key,
                    orderedPairs[3].Key
                });
            }

            bool isFlush = ((suitCounts[(int)'S'] == 5) || (suitCounts[(int)'C'] == 5) || (suitCounts[(int)'H'] == 5) || (suitCounts[(int)'D'] == 5));
            bool isStraight = IsStraight(rankedHand);

            if (isFlush && isStraight)
            {
                // straight flush (87654), score as 8gfedc
                return (char)Constants.HandResult.StraightFlush + rankedHand.ToString();
            }

            if (isFlush)
            {
                // flush (87654), score as 5gfedc
                return (char)Constants.HandResult.Flush + rankedHand.ToString();
            }

            if (isStraight)
            {
                // straight flush (87654), score as 4gfedc
                return (char)Constants.HandResult.Straight + rankedHand.ToString();
            }
                
            // high card (A9752), score as 000.mhfda
            return (char) Constants.HandResult.HighCard + rankedHand.ToString();
        }

        private bool IsStraight(StringBuilder rankedHand)
        {
            int highCard = (int) rankedHand[0];
            int currentCardValue;
            for (int card = 1; card < 4; card++)
            {
                currentCardValue = (int)rankedHand[card];
                if (currentCardValue != (highCard - card))
                    return false;
            }

            return true;
        }

        private void UpdatePairs(ref Dictionary<char, int> pairs, char cardValue)
        {
            if (pairs == null)
            {
                pairs = new Dictionary<char, int>(5);
                pairs.Add(cardValue, 1);
            }
            else
            {
                if (pairs.ContainsKey(cardValue))
                    pairs[cardValue]++;
                else
                    pairs.Add(cardValue, 1);
            }
        }

    }  // end class
}  // end nmaespace

