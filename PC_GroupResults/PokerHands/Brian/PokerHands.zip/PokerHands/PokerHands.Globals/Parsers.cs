﻿namespace PokerHands.Globals
{

    public class Parsers
    {

        public static int IntParseFast(string value)
        {
            int result = 0;
            for (int i = 0; i < value.Length; i++)
            {
                result = 10 * result + (value[i] - 48);
            }
            return result;
        }

    }  // end class

}
