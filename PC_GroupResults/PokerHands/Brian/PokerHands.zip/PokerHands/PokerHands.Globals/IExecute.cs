﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerHands.Globals
{

    public interface IExecute
    {

        string ResultsFileName { get; set; }
        ExecuteResults Execute(string inputFileName);

    }  // end interface

}
