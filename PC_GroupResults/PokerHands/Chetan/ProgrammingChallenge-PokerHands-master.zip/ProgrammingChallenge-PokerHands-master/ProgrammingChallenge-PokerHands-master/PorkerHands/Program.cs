﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using PorkerHands.HandAnalyzers;
using PorkerHands.Comparers;

namespace PorkerHands
{
    class Program
    {
        static void Main(string[] args)
        {
            var text = File.ReadAllLines("PokerHands-input.txt");
            double totalTime = 0;
            int numberOfRuns = 20;

            for (var i = 0; i < numberOfRuns; i++)
            {
                Stopwatch stopWatch = new Stopwatch();
                stopWatch.Start();

                ProcessLines(text);

                stopWatch.Stop();
                TimeSpan ts = stopWatch.Elapsed;
                totalTime += ts.TotalMilliseconds;

                Console.WriteLine(ts.TotalMilliseconds + " - Run " + i);
            }

            Console.WriteLine("Avg Time: " + (totalTime / numberOfRuns));

            var tasks = ProcessLines(text);

            StringBuilder sb = new StringBuilder();
            var blackWins = 0;
            var whiteWins = 0;
            var ties = 0;

            foreach (var task in tasks)
            {
                if (task.Result == StaticObjects.BLACK_WINS)
                    blackWins += 1;
                else if (task.Result == StaticObjects.WHITE_WINS)
                    whiteWins += 1;
                else
                    ties += 1;
            }

            sb.Append("Black Wins: " + blackWins + " , " + "White Wins: " + whiteWins + " , " + "Ties: " + ties);

            File.WriteAllText("output.txt", sb.ToString());

            Console.ReadLine();
        }

        static Task<string>[] ProcessLines(string[] lines)
        {
            var analyzers = GetAnalyzers();

            int taskCount = 0;
            Task<string>[] tasks = new Task<string>[lines.Count()];

            foreach (var line in lines)
            {
                int localTaskCount = taskCount;
                tasks[localTaskCount] = Task<string>.Factory.StartNew(() => 
                {
                    var allCards = line.Split(' ');

                    var blackCards = new List<Card>();
                    var whiteCards = new List<Card>();

                    for (var i = 0; i < 10; i++)
                    {
                        var playerCard = new Card { OriginalCardValueString = allCards[i].ToUpper() };

                        if (i < 5)
                            blackCards.Add(playerCard);
                        else
                            whiteCards.Add(playerCard);
                    }

                    return new Analyzer(blackCards, whiteCards, analyzers).GetWinner();
                });
                taskCount++;
            }

            Task.WaitAll(tasks);

            return tasks;
        }

        static IEnumerable<IHandStrengthAnalyzer> GetAnalyzers()
        {
            var highCardTieComparer = new HighCardTieComparer();
            var highCardHandTieComparer = new HighCardHandTieComparer();
            var flushAnalyzer = new FlushAnalyzer(highCardHandTieComparer);
            var straightAnalyzer = new StraightAnalyzer(highCardTieComparer);
            var threeOfAKindAnalyzer = new ThreeOfAKindAnalyzer(highCardTieComparer);
            var pairAnalyzer = new PairAnalyzer(highCardHandTieComparer);

            var analyzers = new List<IHandStrengthAnalyzer>();
            analyzers.Add(new StraightFlushAnalyzer(flushAnalyzer, straightAnalyzer, highCardTieComparer));
            analyzers.Add(new FourOfAKindAnalyzer(highCardTieComparer));
            analyzers.Add(new FullHouseAnalyzer(threeOfAKindAnalyzer, pairAnalyzer, highCardTieComparer));
            analyzers.Add(flushAnalyzer);
            analyzers.Add(straightAnalyzer);
            analyzers.Add(threeOfAKindAnalyzer);
            analyzers.Add(new TwoPairAnalyzer(pairAnalyzer, highCardHandTieComparer));
            analyzers.Add(pairAnalyzer);
            analyzers.Add(new HighCardAnalyzer(highCardHandTieComparer));

            return analyzers;
        }
    }
}
